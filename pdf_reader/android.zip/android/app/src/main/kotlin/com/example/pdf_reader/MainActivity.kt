package com.example.pdf_reader

import android.content.Intent
import android.net.Uri
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream

class MainActivity : FlutterActivity() {

    private val METHOD_CHANNEL = "pdf_reader/intent"
    private val EVENT_CHANNEL  = "pdf_reader/intent_event"

    private var eventSink: EventChannel.EventSink? = null
    private var pendingUri: String? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, METHOD_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    "getInitialUri" -> {
                        val uri = extractUri(intent)
                        if (uri != null) resolveAndReturn(uri, result)
                        else result.success(null)
                    }

                    "resolveContentUri" -> {
                        val uri = call.arguments as? String
                        if (uri == null) { result.success(null); return@setMethodCallHandler }
                        resolveAndReturn(uri, result)
                    }

                    else -> result.notImplemented()
                }
            }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EVENT_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(args: Any?, sink: EventChannel.EventSink?) {
                    eventSink = sink
                    pendingUri?.let { uri ->
                        pendingUri = null
                        deliverUri(uri)
                    }
                }
                override fun onCancel(args: Any?) { eventSink = null }
            })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val uri = extractUri(intent) ?: return
        deliverUri(uri)
    }

    // ── URI extraction ────────────────────────────────────────────────────────

    private fun extractUri(intent: Intent?): String? {
        if (intent == null) return null
        return when (intent.action) {
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                val streamUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                }
                streamUri?.toString()
                    ?: intent.clipData?.getItemAt(0)?.uri?.toString()
            }
            else -> {
                intent.data?.toString()
                    ?: intent.clipData?.getItemAt(0)?.uri?.toString()
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun resolveAndReturn(uri: String, result: MethodChannel.Result) {
        scope.launch {
            val path = resolveUri(uri)
            withContext(Dispatchers.Main) { result.success(path) }
        }
    }

    private fun deliverUri(uri: String) {
        scope.launch {
            val path = resolveUri(uri)
            withContext(Dispatchers.Main) {
                if (path != null) eventSink?.success(path)
                else pendingUri = uri
            }
        }
    }

    private fun resolveUri(uri: String): String? {
        return try {
            when {
                uri.startsWith("file://")    -> uri.removePrefix("file://")
                uri.startsWith("content://") -> copyContentUri(Uri.parse(uri))
                uri.startsWith("/")          -> uri
                else                         -> null
            }
        } catch (e: Exception) { null }
    }

    private fun copyContentUri(uri: Uri): String? {
        return try {
            val cr = contentResolver

            val displayName = cr.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && idx >= 0) cursor.getString(idx) else null
            }

            val fileName = displayName ?: run {
                val mimeType = cr.getType(uri)
                val ext = mimeToExtension(mimeType)
                "external_${System.currentTimeMillis()}$ext"
            }

            val outFile = File(cacheDir, fileName)
            cr.openInputStream(uri)?.use { input ->
                FileOutputStream(outFile).use { output -> input.copyTo(output) }
            }
            outFile.absolutePath
        } catch (e: Exception) { null }
    }

    private fun mimeToExtension(mimeType: String?): String = when (mimeType) {
        "application/pdf"                                                                -> ".pdf"
        "application/msword"                                                             -> ".docx"
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"       -> ".docx"
        "application/vnd.ms-excel"                                                      -> ".xlsx"
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"             -> ".xlsx"
        "application/vnd.ms-powerpoint"                                                 -> ".pptx"
        "application/vnd.openxmlformats-officedocument.presentationml.presentation"     -> ".pptx"
        "text/plain"                                                                     -> ".txt"
        "text/csv", "text/comma-separated-values"                                       -> ".csv"
        "image/jpeg"                                                                     -> ".jpg"
        "image/png"                                                                      -> ".png"
        else                                                                             -> ".bin"
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}